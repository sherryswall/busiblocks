function showPrint() {
     document.getElementById("wait").style.display = "none";
}